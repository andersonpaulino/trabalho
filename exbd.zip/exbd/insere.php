<?php
    //verifica se existe conexão com bd, caso não tenta criar uma nova
    $conexao = mysqli_connect("localhost","root","") //porta, usuário, senha
    or die("Erro na conexão com banco de dados"); //caso não consiga conectar mostra a mensagem de erro mostrada na conexão
     
    $select_db = mysqli_select_db($conexao,"base_teste"); //seleciona o banco de dados
     
    //Abaixo atribuímos os valores provenientes do formulário pelo método POST
    $nome = $_POST["nome"]; 
    $senha = $_POST["senha"];
    
     
    $string_sql = "INSERT INTO usuarios (id,nome,senha) VALUES (null,'$nome','$senha')"; //String com consulta SQL da inserção
     
    mysqli_query($conexao,$string_sql); //Realiza a consulta
     
    if(mysqli_affected_rows() == 1){ //verifica se foi afetada alguma linha, nesse caso inserida alguma linha
        echo "<p>Cadastro feito com sucesso</p>";
        echo '<a href="index.html">Voltar para formulário de cadastro</a>'; //Apenas um link para retornar para o formulário de cadastro
    } else {
        echo "Erro, não possível inserir no banco de dados";
    }
     
    mysqli_close($conexao); //fecha conexão com banco de dados 
?>