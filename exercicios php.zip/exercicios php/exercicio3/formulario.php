<?php
$cookie_name = "email";
$cookie_value = "andersonm1995@gmail.com";

setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day
?>

<html>
<body>

Bem vindo <?php echo $_POST["nome"]; ?><br>
Seu email é: <?php echo $_POST["email"]; ?>

<?php
if(!isset($_COOKIE[$cookie_name])) {
    echo "Cookie  '" . $cookie_name . "' nao está configurado!";
} else {
    echo "Cookie '" . $cookie_name . "' está configurado!<br>";
    echo "Valor é: " . $_COOKIE[$cookie_name];
}
?>
</body>
</html>