
<html>
<body>
<form action="formulario.php" method="post">
usuario: <input type="text" name="nome"><br>
email: <input type="text" name="email"><br>
senha:<input type="password" name="senha" id="senha"/><br />
<input type="submit">

</form>


</body>
</html>