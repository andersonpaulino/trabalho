<?php
session_start();
$_SESSION['formulario'] = $_POST;
header("Location:saida2.php");
?>

