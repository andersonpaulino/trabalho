
<html>
<body>
<form action="saida.php" method="post">
usuario: <input type="text" name="nome"><br>

senha:<input type="password" name="senha" id="senha"/><br />
<input type="submit">

</form>


</body>
</html>