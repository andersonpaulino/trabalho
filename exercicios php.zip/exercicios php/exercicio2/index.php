<html>
<body>

<h1></h1>
<p></p>
<head class="cabecalho">

<?php require 'head.php'; ?>
</footer>

<div class="menu">
<?php require 'menu.php'; ?>
</div>

<section class="conteudo-principal">
	    <article class="noticia">
		    
		    <h1>Apresentando a página</h1>
			<h5>02 de março de 2016 às 20:18 por Anderson P.</h5>
			<section>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi arcu mi, cursus et tellus id, 
			pellentesque ornare quam. Quisque sed justo quis risus scelerisque tincidunt. 
			Proin faucibus nunc in quam aliquam, et maximus mi auctor. Mauris dapibus ac nulla egestas iaculis. 
			Sed et sapien et diam tincidunt tincidunt sed at risus. Sed ac tincidunt dolor. Suspendisse hendrerit varius lorem. 
			Sed feugiat purus eu eros laoreet tempus. Nulla at aliquet sapien, vel condimentum odio.</p>
			<p>Quisque et dapibus lectus, vel ultricies metus. Morbi volutpat varius nisi, ac auctor mauris feugiat in. 
			Donec condimentum gravida aliquam. Fusce vehicula purus enim, sit amet tincidunt tortor rutrum ac. 
			Proin quis enim in lectus porta facilisis. Suspendisse porta ullamcorper nunc, at mattis massa. 
			Nam viverra, nisl ut pretium ullamcorper, diam nisl eleifend dolor, nec bibendum ligula nisl efficitur metus. 
			Aliquam ultricies, risus non commodo scelerisque, elit mi faucibus augue, id molestie lorem erat vitae tellus. 
			Nam accumsan pellentesque sem et efficitur. Fusce sit amet congue mauris. Mauris vehicula lacinia neque eu accumsan. 
			Quisque lobortis volutpat risus eget ornare. Vestibulum vitae nulla sed magna fermentum ullamcorper. 
			Donec consequat vitae est et gravida. Aenean a gravida sapien, ac condimentum elit.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec purus dolor, ultricies nec condimentum vitae, accumsan eu dolor.
			Maecenas eget porttitor ante. Aenean tempor augue id aliquam tempus. Etiam dictum risus nec est laoreet varius. 
			Etiam pulvinar lectus vitae nunc mollis pulvinar. Pellentesque vehicula id urna sed accumsan.</p>
			<p>Nunc dignissim ornare lorem vitae sollicitudin. Sed sollicitudin sapien quis quam blandit egestas. Duis tincidunt vehicula ipsum non feugiat. 
			Vivamus porta lorem neque, et hendrerit nisl maximus et. Donec et varius lectus. Nam faucibus sapien ut neque porta, vel convallis nunc consectetur. 
			Nunc non velit vel tellus sodales imperdiet.</p>
			<p>Nunc tincidunt mauris quis diam dignissim, vitae dignissim ligula laoreet. Phasellus mattis pretium elit in accumsan. 
			Fusce congue sollicitudin arcu, sit amet euismod ex mattis facilisis. Morbi velit justo, suscipit sed laoreet non, porta aliquet ligula. 
			Curabitur vitae sapien cursus ligula facilisis consequat. Duis malesuada tellus id blandit dignissim. 
			Duis molestie sagittis libero, sed pellentesque diam. Sed posuere blandit hendrerit. Sed est enim, faucibus a est at, venenatis pharetra arcu. 
			Nulla facilisi. Curabitur et quam quis lectus dignissim consectetur. Pellentesque condimentum hendrerit augue sed feugiat. 
			Nam nisl quam, fermentum in convallis ac, semper nec nulla. Sed a tincidunt lorem. Curabitur finibus sapien a sapien efficitur congue. 
			Sed porttitor arcu turpis, nec facilisis libero dictum convallis.</p>
			</section>
			<div>
			   <a href="#">python</a>,
			   <a href="#">C</a>,
			   <a href="#">java</a>,
			   
			</div>
		</article>
    </section>
<footer class="rodape">

<?php require 'footer.php'; ?>
</footer>
</body>
</html>