<?php
echo "<p>Copyright &copy; 2016 - ".date("Y"). "MeuArquivo.com</p>";
?>