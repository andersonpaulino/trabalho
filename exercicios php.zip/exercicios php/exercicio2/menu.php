<?php
echo '<a href="/index.php">home</a>-
<a href="/contact.php">contact</a>-
<a href="/about.php">about</a>
';

?>