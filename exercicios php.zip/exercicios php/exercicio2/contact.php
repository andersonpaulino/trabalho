<html>
<body>

<h1></h1>
<p></p>
<head class="cabecalho">

<?php require 'head.php'; ?>
</head>

<div class="menu">
<?php require 'menu.php'; ?>
</div>
<footer class="rodape">

<?php require 'footer.php'; ?>
</footer>


</body>
</html>