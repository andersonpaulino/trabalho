<head>
<meta charset=UTF-8>
<title>Meu arquivo.php</title>
<link href="estilo.css" rel="stylesheet" type="text/css">
</head>