<html>
<body>

<h1></h1>
<p></p>
<head class="cabecalho">

<?php require 'head.php'; ?>
</head>

<div class="menu">
<?php require 'menu.php'; ?>
</div>

<?php
echo "<p> meuarquivo.com � um site voltado ao compartilhamento de materiais sobre programa��o.</p>";
?>


<footer class="rodape">

<?php require 'footer.php'; ?>
</footer>


</body>
</html>