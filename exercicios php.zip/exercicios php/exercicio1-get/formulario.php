<html>
<body>

Bem vindo <?php echo $_GET["name"]; ?><br>
Seu email é: <?php echo $_GET["email"]; ?>

</body>
</html>