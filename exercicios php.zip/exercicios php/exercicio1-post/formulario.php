<html>
<body>

Bem vindo <?php echo $_POST["name"]; ?><br>
Seu email é: <?php echo $_POST["email"]; ?>

</body>
</html>